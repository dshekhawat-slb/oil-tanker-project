import streamlit as st

class pred():

    def app(self):
        st.title("Streamlit Pred")

if __name__=='__main__':
    app =pred()
    app.app()
